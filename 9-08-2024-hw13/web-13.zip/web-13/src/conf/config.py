from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    POSTGRES_DB: str = "postgres"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_PORT: int = 5432

    SQLALCHEMY_DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/postgres"

    SECRET_KEY: str = "secret"
    ALGORITHM: str = "HS256"

    MAIL_USERNAME: str
    MAIL_PASSWORD: str
    MAIL_FROM: str
    MAIL_PORT: int = 465
    MAIL_SERVER: str
    TEMPLATE_FOLDER: Path = Path(__file__).parent.parent / 'templates'

    REDIS_URL: str = "redis://localhost:6379/0"

    class Config:
        extra = "ignore"
        env_file = "../../env"
        env_file_encoding = "utf-8"


settings = Settings()
