import jwt
from datetime import datetime, timedelta
import pytz

SECRET_KEY = 'secret'
ALGORITHM = 'HS256'

def create_email_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(pytz.UTC) + timedelta(days=100)
    to_encode.update({"iat": datetime.now(pytz.UTC), "exp": expire})
    token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return token

def get_email_from_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        print("Token has expired")
        return None
    except jwt.InvalidTokenError:
        print("Invalid token")
        return None

# Пример использования
data = {"sub": "hajore6558@foraro.com"}
token = create_email_token(data)
print("Generated Token:", token)

email = get_email_from_token(token)
print("Extracted Email:", email)